<?php
include '../Model/variablesDeSesion.php';

//Devuelve el tipo de usuario actual
echo obtTipoUsuario();

?>