<?php


include '../Model/cerrarCurso.php';

echo "PRUEBA."

}